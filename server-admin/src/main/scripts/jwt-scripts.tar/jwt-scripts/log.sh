# prints the tail of the current log file. make sure to set the environment variable before running this.
tail -50 $JWT_LOG